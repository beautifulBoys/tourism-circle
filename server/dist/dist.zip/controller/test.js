'use strict';

function a() {
  console.log('大师傅的说法是的访客的设计费里的数据付了款接待来访');
}
//# sourceMappingURL=test.js.map