"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    project_port: 3001,
    chat_room_port: 3003,
    robot_id: 10,
    group_id: 20
};
//# sourceMappingURL=index.js.map